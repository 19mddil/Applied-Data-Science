//comparison operators always return true or false

console.log(4==4)
var a = 4;
var b = 5;
var c = 4;
console.log(4 == 5)
console.log(a == c)
console.log(4 == "4")// doesnt inclue type as matter
console.log(4 === "4")// takes type into account
console.log( 4 != 5);
console.log( 4 !==4 );
console.log(4 !== "4");
console.log(5 > 4);
console.log(5 > "9");
console.log("5"> "4");
var c = (5>4);
console.log(c);

//logical oprators



//condtional
var a = (1 < 8)?"Hello":"world";
console.log(a);
var a = !(1<8)?"Hello":"World";
console.log(a);
