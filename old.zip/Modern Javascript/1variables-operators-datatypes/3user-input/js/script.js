var x;
x = prompt("Enter your name: ");
console.log(x);
document.write(x);
