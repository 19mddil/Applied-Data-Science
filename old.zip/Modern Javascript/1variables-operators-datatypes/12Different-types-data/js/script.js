/*
    Different types of data
        *Number
        *Strings
        *Booleans
        *Arrays
        *Objects(Like python dictionary)
*/
/*
    More Types of Data
        Undefined
        Empty Value
        null
        NaN      
*/
