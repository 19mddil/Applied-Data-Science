const a = 2;
// This will generate a mistake now. a = 3;
// kewords(Reserved words in javascript)
let a;
let b = a;
a = 90;