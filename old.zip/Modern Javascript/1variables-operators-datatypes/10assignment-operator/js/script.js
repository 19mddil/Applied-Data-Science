var a = 19;
var b = 12;
a = b;
console.log(a);
var c;
c = a + b;
console.log(c);
var a = 10
a += 12;
console.log(a);

var n = "hello";
n += " world";
console.log(n);
