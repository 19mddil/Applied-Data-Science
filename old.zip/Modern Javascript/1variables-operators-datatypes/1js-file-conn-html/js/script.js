console.log("I am \"first\" line.");
console.log('I am "second" line.');
console.log("I am 'third' line.");
document.write("I love you baby.<br>");
document.write(67.14);
// commenting is like C.