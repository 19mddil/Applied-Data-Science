var arr = [1,2,3];
var student = {
    name : "Md.Dilshad",
    age : 25,
    hometown : "Dhaka"
};
student["occu"] = "student";
student.village = "kurigram";
delete student.village;
var teacher = {};
