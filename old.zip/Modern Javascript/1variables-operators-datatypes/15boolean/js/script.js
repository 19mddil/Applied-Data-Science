var x = 10 < 9;
console.log(x);
x = true;
console.log(x);
x = "bohubrihi";
console.log(Boolean(x));
var y;
console.log(Boolean(y));
var z = null;
console.log(Boolean(z));
x = 10/"h";
console.log(x);
console.log(Boolean(x));
// undefined, null, NaN boolean will give false.
