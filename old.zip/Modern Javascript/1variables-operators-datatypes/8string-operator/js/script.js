var line1 = "hello";
var line2 = "world!";
console.log(line1+" "+line2);
var weird = 36 + "what";
console.log(weird);
var weird2 = "hello"+34+4;
console.log(weird2);
var weird3 = 34+4+"hello";
console.log(weird3);
var numString1 = "76";
var numString2 = "7";
var sub = numString1 - numString2;
console.log(sub);
var addi = numString1 + numString2;
console.log(addi);
var weirdMax = "45" - "Simanta";
console.log(weirdMax);
// NaN not a number.. In some cases its stored on variable like here in weirdMax
