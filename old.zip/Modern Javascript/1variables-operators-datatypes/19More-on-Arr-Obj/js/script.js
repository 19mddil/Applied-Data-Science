var arr = [10,11,["a","b"],12,8,9];
var arr1 = [1,2,["a",["word1","word2"],"b"],7,8];
var arr2 = [1,2,{ name:"lamborghini",type:"sports",genre:"aventador"},3];
