var c = prompt("Enter Temperature in celcius");
var f  = 9/5*c + 32;
alert("Farenheit: "+f+" Degree");
console.log("Task Complete");