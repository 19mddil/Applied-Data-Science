var a = 5;
var b = 7;
a++;
++b;
console.log(a);
console.log(b);