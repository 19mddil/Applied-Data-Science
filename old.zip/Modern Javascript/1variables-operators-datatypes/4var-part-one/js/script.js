var myName;
let herName;

myName = prompt("Enter your Name: ");

console.log(myName);
document.getElementById("spot").innerHTML = myName;
