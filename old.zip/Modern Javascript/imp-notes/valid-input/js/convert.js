var z = prompt("Enter the value:");
console.log("Number : "+!isNaN(z));
var x = parseFloat(z);// x = 123
var y = x.toString();
var l = y.length;
console.log("Float Number : "+x);
console.log(" number :"+ !isNaN(x));
console.log(z.length == y.length);

