import java.util.*;
import java.awt.event.*;
import javax.swing.*;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import javax.swing.JPanel;
import java.io.IOException;
import javax.swing.border.Border;

public class Home {
    private JFrame f;
    public static void main(String args[]){
        new Home().go();
    }       

    void go(){
        BufferedImage myPicture = null;
        try{
            myPicture = ImageIO.read(new File("flashcard-maker.jpg"));
        }catch (IOException ex){
            //
        }
        JLabel wIcon = new JLabel(new ImageIcon(myPicture));
        Font font = new Font("Monospace",Font.PLAIN, 20);
        f = new JFrame("Flash Cards Home");
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel mainPanel = new JPanel();
        JButton b1 = new JButton("Make Flash Cards");
        JButton b2 = new JButton("See Flash Cards");
        b1.setFont(font);
        b1.setForeground(Color.GRAY);
        b1.setBackground(Color.BLACK);
        b2.setFont(font);
        b2.setForeground(Color.GRAY);
        b2.setBackground(Color.BLACK);
        mainPanel.add(b1);
        mainPanel.add(b2);
        mainPanel.add(wIcon);

        b1.addActionListener(new B1Listener());
        b2.addActionListener(new B2Listener());
        
        f.getContentPane().add(BorderLayout.CENTER, mainPanel);
        f.setSize(400,400);
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        f.setVisible(true);
    }

    public class B1Listener implements ActionListener{
        public void actionPerformed(ActionEvent ev){
            f.setVisible(false);
            new QuizCardBuilder().go();
        }
    }

    public class B2Listener implements ActionListener{
        public void actionPerformed(ActionEvent ev){
            f.setVisible(false);
            new QuizCardReader().go();
        }
    }

}
