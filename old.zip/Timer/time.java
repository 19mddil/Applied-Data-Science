//import static user.*;
import java.util.Calendar;

import java.util.*;
import java.awt.event.*;
import javax.swing.*;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import javax.swing.JPanel;
import java.io.IOException;
import javax.swing.border.Border;

class time{
	private JFrame f;
	private plan p1;
	private double total_course = 515;
	JTextArea totalDoneCourse;
	JLabel requiredRate;
	JTextArea sdt1;
	JTextArea sdt2;
	JTextArea sdt3;
	JTextArea d;
	JLabel startingDate; 
	JLabel endingDate;
	JLabel daysPassed;
	JLabel timeRemains;
	
	public static void main(String[] args){
		new time().go();
		///use user class to set it....
		//System.out.println("\n\n*********Candle*********\n\n");
		//p1.set(24,7,2021,99);
		//p1.find_ending_date();
		//p1.days_passed();
		//p1.time_remains();
		//System.out.println("\n\nMotive: To become a javascript full stack developer.");
		
	}

	double getRequiredRate(double y,String x){
		String numOfDays = x.substring(14,16);
		int days_left =  Integer.parseInt(numOfDays)+1;
		return y/days_left;
	} 

	void go(){
		p1 = new plan();
		p1.set(24,7,2021,99);

		f = new JFrame("Candle");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel mainPanel = new JPanel();

		sdt1 = new JTextArea(1,2);
		sdt2 = new JTextArea(1,2);
		sdt3 = new JTextArea(1,4);
		d = new JTextArea(1,4);

		JLabel sDate = new JLabel("Starting Date (dd/mm/yyyy): ");
		JLabel days = new JLabel("     Spanning Days(digits) : ");
		startingDate = new JLabel();
		endingDate = new JLabel();
		daysPassed = new JLabel();
		timeRemains = new JLabel();
		JLabel motive = new JLabel();
		requiredRate = new JLabel();
		JLabel tt = new JLabel("Input DoneNumberCourse : ");
		totalDoneCourse = new JTextArea(1,5);
		JButton findRequiredRate = new JButton("Find RR Now");
		JButton enter = new JButton("Refresh the Infos");

		findRequiredRate.addActionListener(new FindRequiredRateListener());
		enter.addActionListener(new EnterListenr());

		startingDate.setText("\nStarting Date : Sat July 30 00:00:00 BDT 2021");
		endingDate.setText(p1.find_ending_date());
		daysPassed.setText(p1.days_passed());
		timeRemains.setText(p1.time_remains());
		motive.setText("Motive: To become a javascript full stack developer.");
		requiredRate.setText("Required Rate(Total Course = 515) : "+Double.toString(getRequiredRate(total_course,p1.time_remains() )));
		
		mainPanel.add(sDate);
		mainPanel.add(sdt1);
		mainPanel.add(sdt2);
		mainPanel.add(sdt3);
		mainPanel.add(days);
		mainPanel.add(d);
		mainPanel.add(enter);
		mainPanel.add(startingDate);
		mainPanel.add(endingDate);
		mainPanel.add(daysPassed);
		mainPanel.add(timeRemains);
		mainPanel.add(motive);
		mainPanel.add(tt);
		mainPanel.add(totalDoneCourse);
		mainPanel.add(findRequiredRate);
		mainPanel.add(requiredRate);

		f.getContentPane().add(BorderLayout.CENTER, mainPanel);
        f.setSize(500,250);
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        f.setVisible(true);


	}

	public class FindRequiredRateListener implements ActionListener {
		public void actionPerformed(ActionEvent ev) {
		   double totalCourseNow = total_course - Double.parseDouble(totalDoneCourse.getText());
		   requiredRate.setText("Required Rate : "+Double.toString(getRequiredRate(totalCourseNow, p1.time_remains() )));
		 }
	 }
	
	public class EnterListenr implements ActionListener{
		public void actionPerformed(ActionEvent ev){
			p1.set(Integer.parseInt(sdt1.getText()),Integer.parseInt(sdt2.getText()),Integer.parseInt(sdt3.getText()),Integer.parseInt(d.getText()));
			startingDate.setText("Starting Date : "+sdt1.getText()+"-"+sdt2.getText()+"-"+sdt3.getText()+" 00:00:00 BDT 2021");
			endingDate.setText(p1.find_ending_date());
			daysPassed.setText(p1.days_passed());
			timeRemains.setText(p1.time_remains());
			requiredRate.setText("Required Rate : "+Double.toString(getRequiredRate(total_course,p1.time_remains() )));
		}
	}
} 